<?php 

//  add custom postype 

$custom_postype = new \Dt_custom_postype\Dt_CustomPosttype;
$taxonomy = new \Dt_custom_postype\Dt_Taxonomies;

$custom_postype->dt_postype('portfolio', 'Portfolio', 'Portfolios', array('title', 'editor', 'author', 'thumbnail', 'excerpt'));
$taxonomy->dt_taxonomy( 'Type', 'Type', 'Types', 'portfolio');

//  team 

$custom_postype->dt_postype('team', 'Team', 'Teams', array('title', 'editor', 'thumbnail'));
$taxonomy->dt_taxonomy( 'group', 'Group', 'Groups', 'team');
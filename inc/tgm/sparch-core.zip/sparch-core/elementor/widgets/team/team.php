<?php
namespace Elementor;

use \WP_Query;


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class droit_portfolio_team
 * @package droit_portfolioCore\Widgets
 */
class DRTH_ESS_team extends Widget_Base {

    public function get_name() {
        return 'droit-team-theme';
    }

    public function get_title() {
        return __( 'Sparch team Us', 'droit_team' );
    }

    public function get_icon() {
        return 'dlicons-blog-post';
    }

    public function get_categories() {
        return [ 'drth_custom_theme' ];
    }


    public function get_style_depends() {
        return ['droit-partner-style'];
    }

	public function get_script_depends(){
		return ['droit-team-script'];
	}


    protected function _register_controls() {


    $pricing_repeater = new \Elementor\Repeater();
    // -------------------------------------------- Filtering
    $this->start_controls_section(
        'droit_team_section', [
            'label' => __( 'Team Design', 'sparch-core' ),

        ]
    );

    $this->add_control('sparch_team_cat',
    [
        'label'     => esc_html__( 'Category', 'sparch-core' ),
        'type'      => \Elementor\Controls_Manager::SELECT2,
        'multiple'  => true,
        'default'   => '',
        'options'   => $this->getCategories(),

    ]
      );
    $this->add_control(
        'sparch_team_post_count',
        [
            'label'         => esc_html__( 'Team Count', 'sparch-core' ),
            'type'          => Controls_Manager::NUMBER,
            'default'       => esc_html__( '6', 'sparch-core'),
        ]
    );  

    $this->add_control(
        'sparch_team_order',
        [
            'label' => esc_html__( 'Team Order', 'sparch-core' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => 'DESC',
            'options' => $this->get_post_order(),
        ]
    );

    $this->add_control(
        'sparch_team_orderby',
        [
            'label' => esc_html__( 'Team Order By', 'sparch-core' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '',
            'options' => $this->get_post_orderby(),
        ]
    );


    $this->end_controls_section(); 

    }
    
    // HTML Render Function --------------------------------
    protected function render() {
    $settings = $this->get_settings(); 
    extract($settings);

    $query = array(
        'post_type'      => 'team',
        'post_status'    => 'publish',
        'posts_per_page' => $sparch_team_post_count,
    );

    if($sparch_team_order != '') {
     $query['order'] = $sparch_team_order;
    }

    if($sparch_team_orderby != '') {
     $query['orderby'] = $sparch_team_orderby;
    }

    if($sparch_team_cat != '' && !empty($sparch_team_cat)){
        $query['tax_query'] = array(
           array(
               'taxonomy' => 'group',
               'terms' => $sparch_team_cat,
               'field' => 'id',
           )
       );
    }

    $get_team_list = get_posts( $query );

?>

    <div class="our_team_area pb-0">
        <div class="container">
            <div class="row team_inner">
                <?php
                    if(is_array( $get_team_list ) && count( $get_team_list) > 0 ){
                   
                    foreach ($get_team_list as $team_info) {
                       $id = $team_info->ID;    
                    ?>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
                   <a href="<?php echo get_the_permalink( $id); ?>">
                   <div class="team_item">
                        <div class="team_img">
                           <?php echo get_the_post_thumbnail($id); ?>
                        </div>
                        <div class="team_text">
                             <h3><?php echo esc_html( get_the_title($id) ); ?></h3>
                            <h5><?php  echo esc_html(get_field('job_title_', $id)) ?></h5>
                            <?php 

                            $get_social_media = get_field('social_profle_', $id);

                            if(is_array($get_social_media) && !empty($get_social_media)){ ?>
                            
                            <ul class="nav">
                              
                              <?php 
                               
                                foreach($get_social_media as $media) {
                                   
                                    ?>
                                    <li><a href="<?php echo esc_url($media['link']); ?>"><i class="<?php echo esc_attr( $media['icon_class_'] ) ?>"></i></a></li>
                                    <?php 
                                }
                              
                              ?>
                            </ul>
                            <?php } ?>
                        </div>
                    </div>
                   </a>
                </div>
                <?php 
                  
                    }
                    }
                ?>
            </div>
        </div>
    </div>
    
<?php
    }

    public function getCategories(){
        $terms = get_terms( array(
            'taxonomy'    => 'group',
            'hide_empty'  => false,
            'posts_per_page' => -1,
        ) );


        $cat_list = [];
        if(is_array($terms) && '' != $terms) :
        foreach($terms as $post) {

            $cat_list[$post->term_id]  = [$post->name];
        }
       endif;
        return $cat_list;
    }

    public function get_post_order() {
        $order = [
            'DESC'  => esc_html__( 'DESC', 'sparch-core' ),
			'ASC' => esc_html__( 'ASC', 'sparch-core' ),
        ];
        return $order;
    }

    public function get_post_orderby() {
        $orderby = [
            'none'  => esc_html__( 'None', 'sparch-core' ),
			'ID' => esc_html__( 'Id', 'sparch-core' ),
			'author' => esc_html__( 'Author', 'sparch-core' ),
			'title' => esc_html__( 'Title', 'sparch-core' ),
			'name' => esc_html__( 'Name', 'sparch-core' ),
			'type' => esc_html__( 'Type', 'sparch-core' ),
			'date' => esc_html__( 'Date', 'sparch-core' ),
			'modified' => esc_html__( 'Modified', 'sparch-core' ),
			'parent' => esc_html__( 'Parent', 'sparch-core' ),
			'rand' => esc_html__( 'Rand', 'sparch-core' ),
        ];
        return $orderby;
    }

}

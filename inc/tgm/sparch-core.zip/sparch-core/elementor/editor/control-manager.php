<?php
namespace DROIT_ELEMENTOR_PRO;

defined( 'ABSPATH' ) || exit;

class DL_Controls_Manager extends \Elementor\Controls_Manager {
    const DLEDITOR = 'dleditor';
}

